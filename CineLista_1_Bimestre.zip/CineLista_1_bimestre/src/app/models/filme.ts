export interface Filme {
  id: number;
  titulo: string;
  tipo: string;
  genero: string;
  nota: number;
  assistido: boolean;
  imagemUrl: string;
  ano: number;
  duracao: string;
  descricao: string;
}

export interface NovoFilme {
  titulo: string;
  tipo: string;
  genero: string;
  nota: number;
  assistido: boolean;
  imagemUrl: string;
  ano: number;
  duracao: string;
  descricao: string;
}
