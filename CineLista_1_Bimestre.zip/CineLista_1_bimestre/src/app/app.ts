import { Component } from '@angular/core';
import { CatalogoFilmes } from './components/catalogo-filmes/catalogo-filmes';
import { FormularioFilme } from './components/formulario-filme/formulario-filme';
import { Filme, NovoFilme } from './models/filme';

@Component({
  selector: 'app-root',
  imports: [CatalogoFilmes, FormularioFilme],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  titulo = 'CineLista';
  subtitulo = 'Filmes, séries e jogos em um só lugar';

  filmes: Filme[] = [
    {
      id: 1, titulo: 'Interestelar', tipo: 'Filme', genero: 'Ficção científica', nota: 9.5,
      assistido: true, ano: 2014, duracao: '2h 49min',
      imagemUrl: 'https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg',
      descricao: 'Exploradores atravessam um buraco de minhoca em busca de um futuro para a humanidade.'
    },
    {
      id: 2, titulo: 'Duna: Parte Dois', tipo: 'Filme', genero: 'Ficção científica', nota: 9.2,
      assistido: true, ano: 2024, duracao: '2h 46min',
      imagemUrl: 'https://image.tmdb.org/t/p/w500/6izwz7rsy95ARzTR3poZ8H6c5pp.jpg',
      descricao: 'Paul Atreides se une aos Fremen enquanto busca vingança contra os responsáveis pela queda de sua família.'
    },
    {
      id: 3, titulo: 'Homem-Aranha no Aranhaverso', tipo: 'Filme', genero: 'Animação', nota: 9.0,
      assistido: true, ano: 2023, duracao: '2h 20min',
      imagemUrl: 'https://image.tmdb.org/t/p/w500/8Vt6mWEReuy4Of61Lnj5Xj704m8.jpg',
      descricao: 'Miles Morales viaja pelo multiverso e encontra diferentes versões do Homem-Aranha.'
    },
    {
      id: 4, titulo: 'Oppenheimer', tipo: 'Filme', genero: 'Drama', nota: 8.9,
      assistido: false, ano: 2023, duracao: '3h',
      imagemUrl: 'https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg',
      descricao: 'A trajetória do físico J. Robert Oppenheimer durante a criação da bomba atômica.'
    },
    {
      id: 5, titulo: 'Batman', tipo: 'Filme', genero: 'Ação', nota: 8.7,
      assistido: false, ano: 2022, duracao: '2h 56min',
      imagemUrl: 'https://image.tmdb.org/t/p/w500/74xTEgt7R36Fpooo50r9T25onhq.jpg',
      descricao: 'Batman investiga uma sequência de crimes que revela a corrupção escondida em Gotham.'
    },
    {
      id: 6, titulo: 'Stranger Things', tipo: 'Série', genero: 'Ficção científica', nota: 9.1,
      assistido: true, ano: 2016, duracao: '50 min/ep.',
      imagemUrl: 'https://image.tmdb.org/t/p/w500/49WJfeN0moxb9IPfGn8AIqMGskD.jpg',
      descricao: 'Amigos enfrentam experimentos secretos e forças sobrenaturais na pequena cidade de Hawkins.'
    },
    {
      id: 7, titulo: 'The Last of Us', tipo: 'Série', genero: 'Drama', nota: 9.3,
      assistido: false, ano: 2023, duracao: '55 min/ep.',
      imagemUrl: 'https://image.tmdb.org/t/p/w500/uKvVjHNqB5VmOrdxqAt2F7J78ED.jpg',
      descricao: 'Joel e Ellie atravessam um mundo devastado enquanto constroem uma relação inesperada.'
    },
    {
      id: 8, titulo: 'Breaking Bad', tipo: 'Série', genero: 'Crime', nota: 9.6,
      assistido: true, ano: 2008, duracao: '5 temporadas',
      imagemUrl: 'https://image.tmdb.org/t/p/w500/ztkUQFLlC19CCMYHW9o1zWhJRNq.jpg',
      descricao: 'Um professor de química entra no mundo do crime após receber um diagnóstico difícil.'
    },
    {
      id: 9, titulo: 'Wandinha', tipo: 'Série', genero: 'Mistério', nota: 8.6,
      assistido: false, ano: 2022, duracao: '50 min/ep.',
      imagemUrl: 'https://image.tmdb.org/t/p/w500/9PFonBhy4cQy7Jz20NpMygczOkv.jpg',
      descricao: 'Wandinha Addams investiga acontecimentos sobrenaturais enquanto estuda na Escola Nunca Mais.'
    },
    {
      id: 10, titulo: 'Arcane', tipo: 'Série', genero: 'Animação', nota: 9.4,
      assistido: true, ano: 2021, duracao: '2 temporadas',
      imagemUrl: 'https://image.tmdb.org/t/p/w500/fqldf2t8ztc9aiwn3k6mlX3tvRT.jpg',
      descricao: 'Duas irmãs seguem caminhos opostos em meio ao conflito entre Piltover e Zaun.'
    },
    {
      id: 11, titulo: 'Cyberpunk 2077', tipo: 'Jogo', genero: 'RPG', nota: 9.0,
      assistido: true, ano: 2020, duracao: 'Mundo aberto',
      imagemUrl: 'https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/1091500/e9047d8ec47ae3d94bb8b464fb0fc9e9972b4ac7/header.jpg',
      descricao: 'V tenta sobreviver em Night City enquanto carrega um implante que ameaça sua identidade.'
    },
    {
      id: 12, titulo: 'God of War Ragnarök', tipo: 'Jogo', genero: 'Ação', nota: 9.5,
      assistido: false, ano: 2022, duracao: 'Ação e aventura',
      imagemUrl: 'https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/2322010/header.jpg',
      descricao: 'Kratos e Atreus atravessam os Nove Reinos diante da chegada do Ragnarök.'
    },
    {
      id: 13, titulo: 'Red Dead Redemption 2', tipo: 'Jogo', genero: 'Aventura', nota: 9.7,
      assistido: true, ano: 2018, duracao: 'Mundo aberto',
      imagemUrl: 'https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/1174180/header.jpg',
      descricao: 'Arthur Morgan enfrenta o fim da era dos fora da lei no oeste americano.'
    },
    {
      id: 14, titulo: 'Elden Ring', tipo: 'Jogo', genero: 'RPG', nota: 9.4,
      assistido: false, ano: 2022, duracao: 'RPG de ação',
      imagemUrl: 'https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/1245620/f0b19c231f86fa0e633ff88a1a63459443017728/header_alt_assets_3.jpg',
      descricao: 'Um Maculado explora as Terras Intermédias em busca do poder do Anel Prístino.'
    },
    {
      id: 15, titulo: 'The Witcher 3: Wild Hunt', tipo: 'Jogo', genero: 'RPG', nota: 9.6,
      assistido: false, ano: 2015, duracao: 'Mundo aberto',
      imagemUrl: 'https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/292030/97cca1147b256f450331044255b1dbd2d57d609e/header_alt_assets_4.jpg',
      descricao: 'Geralt de Rívia procura Ciri enquanto uma ameaça sobrenatural avança pelo continente.'
    }
  ];

  adicionarFilme(novoFilme: NovoFilme): void {
    let proximoId = 1;

    for (let filme of this.filmes) {
      if (filme.id >= proximoId) {
        proximoId = filme.id + 1;
      }
    }

    const filme: Filme = {
      id: proximoId,
      titulo: novoFilme.titulo,
      tipo: novoFilme.tipo,
      genero: novoFilme.genero,
      nota: novoFilme.nota,
      assistido: novoFilme.assistido,
      imagemUrl: novoFilme.imagemUrl,
      ano: novoFilme.ano,
      duracao: novoFilme.duracao,
      descricao: novoFilme.descricao
    };

    this.filmes.push(filme);
  }

  removerFilme(id: number): void {
    for (let i = 0; i < this.filmes.length; i++) {
      if (this.filmes[i].id === id) {
        this.filmes.splice(i, 1);
        break;
      }
    }
  }

  alternarStatus(id: number): void {
    for (let filme of this.filmes) {
      if (filme.id === id) {
        filme.assistido = !filme.assistido;
        break;
      }
    }
  }
}
