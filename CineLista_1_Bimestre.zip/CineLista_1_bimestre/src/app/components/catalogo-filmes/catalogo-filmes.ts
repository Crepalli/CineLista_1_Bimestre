import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Filme } from '../../models/filme';

@Component({
  selector: 'app-catalogo-filmes',
  imports: [FormsModule],
  templateUrl: './catalogo-filmes.html',
  styleUrl: './catalogo-filmes.css',
})
export class CatalogoFilmes {
  @Input() filmes: Filme[] = [];
  @Output() filmeRemovido = new EventEmitter<number>();
  @Output() statusAlterado = new EventEmitter<number>();

  busca = '';
  tipoSelecionado = 'Todos';
  generoSelecionado = 'Todos';
  filmeSelecionado: Filme | null = null;

  tipos = ['Todos', 'Filme', 'Série', 'Jogo'];

  obterGeneros(): string[] {
    const generos: string[] = ['Todos'];

    for (let filme of this.filmes) {
      const tipoCorreto = this.tipoSelecionado === 'Todos'
        || filme.tipo === this.tipoSelecionado;

      if (tipoCorreto && !generos.includes(filme.genero)) {
        generos.push(filme.genero);
      }
    }

    return generos;
  }

  obterFilmesFiltrados(): Filme[] {
    const termo = this.busca.trim().toLowerCase();
    const resultado: Filme[] = [];

    for (let filme of this.filmes) {
      const correspondeBusca = filme.titulo.toLowerCase().includes(termo);
      const correspondeTipo = this.tipoSelecionado === 'Todos'
        || filme.tipo === this.tipoSelecionado;
      const correspondeGenero = this.generoSelecionado === 'Todos'
        || filme.genero === this.generoSelecionado;

      if (correspondeBusca && correspondeTipo && correspondeGenero) {
        resultado.push(filme);
      }
    }

    return resultado;
  }

  obterMinhaLista(): Filme[] {
    const lista: Filme[] = [];

    for (let filme of this.filmes) {
      if (!filme.assistido) {
        lista.push(filme);
      }
    }

    return lista;
  }

  selecionarGenero(genero: string): void {
    this.generoSelecionado = genero;
  }

  selecionarTipo(tipo: string): void {
    this.tipoSelecionado = tipo;
    this.generoSelecionado = 'Todos';
  }

  abrirDetalhes(filme: Filme): void {
    this.filmeSelecionado = filme;
  }

  fecharDetalhes(): void {
    this.filmeSelecionado = null;
  }

  usarCapaPadrao(evento: Event): void {
    const imagem = evento.target as HTMLImageElement;
    imagem.src = '/imagens/capa-padrao.svg';
  }

  remover(id: number): void {
    this.filmeRemovido.emit(id);
  }

  alternarStatus(id: number): void {
    this.statusAlterado.emit(id);
  }
}
