import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NovoFilme } from '../../models/filme';

@Component({
  selector: 'app-formulario-filme',
  imports: [FormsModule],
  templateUrl: './formulario-filme.html',
  styleUrl: './formulario-filme.css',
})
export class FormularioFilme {
  @Output() filmeAdicionado = new EventEmitter<NovoFilme>();

  titulo = '';
  tipo = 'Filme';
  genero = '';
  nota: number | null = null;
  assistido = false;
  imagemUrl = '';
  capaPadrao = '/imagens/capa-padrao.svg';
  mensagem = '';

  adicionar(): void {
    if (!this.formularioValido()) {
      return;
    }

    this.filmeAdicionado.emit({
      titulo: this.titulo.trim(),
      tipo: this.tipo,
      genero: this.genero,
      nota: Number(this.nota),
      assistido: this.assistido,
      imagemUrl: this.imagemUrl.trim() || this.capaPadrao,
      ano: new Date().getFullYear(),
      duracao: 'A definir',
      descricao: 'Novo título adicionado à sua coleção pessoal.'
    });

    this.mensagem = `"${this.titulo.trim()}" foi adicionado à galeria.`;
    this.limparFormulario();
  }

  formularioValido(): boolean {
    return this.titulo.trim().length >= 2 && this.genero !== '' && this.nota !== null
      && this.nota >= 0 && this.nota <= 10;
  }

  selecionarImagem(evento: Event): void {
    const campo = evento.target as HTMLInputElement;

    if (!campo.files || campo.files.length === 0) {
      return;
    }

    const arquivo = campo.files[0];

    if (!arquivo.type.startsWith('image/')) {
      return;
    }

    const leitor = new FileReader();
    leitor.onload = () => {
      this.imagemUrl = String(leitor.result);
    };
    leitor.readAsDataURL(arquivo);
  }

  usarCapaPadrao(evento: Event): void {
    const imagem = evento.target as HTMLImageElement;
    imagem.src = this.capaPadrao;
  }

  private limparFormulario(): void {
    this.titulo = '';
    this.tipo = 'Filme';
    this.genero = '';
    this.nota = null;
    this.assistido = false;
    this.imagemUrl = '';
  }
}
